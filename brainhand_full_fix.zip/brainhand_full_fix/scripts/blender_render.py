import sys
import os
import traceback

try:
    import bpy
except Exception as e:
    print("Error: this script must be run inside Blender (using the Blender executable).")
    print("Run: blender -b <blendfile> --python blender_render.py -- <output_path> <frame>")
    print("ImportError:", e)
    sys.exit(1)


def parse_args(argv):
    # Extract arguments after the '--' marker if present (Blender passes those to the script)
    if "--" in argv:
        return argv[argv.index("--") + 1 :]
    return []


def main():
    argv = parse_args(sys.argv)
    if len(argv) < 2:
        print("Usage: blender -b <blendfile> --python blender_render.py -- <output_path> <frame>")
        sys.exit(1)

    output_path = argv[0]
    try:
        frame = int(argv[1])
    except ValueError:
        print(f"Invalid frame value: {argv[1]}")
        sys.exit(1)

    # Ensure output directory exists
    out_dir = os.path.dirname(os.path.abspath(output_path))
    if out_dir and not os.path.exists(out_dir):
        try:
            os.makedirs(out_dir, exist_ok=True)
        except Exception as e:
            print(f"Could not create output directory {out_dir}: {e}")
            sys.exit(1)

    # Set scene frame and output filepath
    bpy.context.scene.frame_set(frame)
    bpy.context.scene.render.filepath = os.path.abspath(output_path)

    # Infer image format from file extension if possible
    _, ext = os.path.splitext(output_path)
    ext = ext.lower().lstrip('.')
    if ext in ('png', 'jpg', 'jpeg', 'tiff', 'bmp', 'exr'):
        fmt_map = {
            'png': 'PNG', 'jpg': 'JPEG', 'jpeg': 'JPEG',
            'tiff': 'TIFF', 'bmp': 'BMP', 'exr': 'OPEN_EXR'
        }
        try:
            bpy.context.scene.render.image_settings.file_format = fmt_map.get(ext, 'PNG')
        except Exception:
            # Some Blender builds may not support certain formats via this API
            pass

    # Perform render and handle any exceptions cleanly
    try:
        bpy.ops.render.render(write_still=True)
    except Exception as e:
        print("Render failed:")
        traceback.print_exc()
        sys.exit(1)

    print(f"Rendered frame {frame} to {output_path}")


if __name__ == "__main__":
    main()
