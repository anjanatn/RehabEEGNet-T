import os, numpy as np
from django.conf import settings
import warnings
try:
    import torch
    import torch.nn as nn
except Exception:
    torch = None
    nn = None

class DeterministicMock:
    def __init__(self, n_classes=5):
        self.n_classes = n_classes
    def predict_from_array(self, arr):
        # arr: channels x samples
        # deterministic: use mean and variance to pick class and degree
        s = np.nan_to_num(arr)
        channel_means = s.mean(axis=1)
        overall_mean = float(channel_means.mean())
        overall_std = float(s.std())
        # class by sign of mean and mod
        cls_idx = int(abs(int(overall_mean * 10)) % self.n_classes)
        deg = float((abs(overall_mean) + overall_std) * 45)  # map to some degrees
        deg = max(0.0, min(180.0, deg))
        probs = [0.0]*self.n_classes
        probs[cls_idx] = 1.0
        return {'class_idx': cls_idx, 'class_probs': probs, 'pred_deg': deg}

class PlaceholderNet:
    # tiny placeholder net for structure (not used unless real model plugged)
    def __init__(self, n_channels=62, n_classes=5):
        self.n_channels = n_channels
        self.n_classes = n_classes


# Define Transformer only if PyTorch is available
if torch is not None and nn is not None:
    class EEGTransformer(nn.Module):
        """
        Transformer-based model for EEG-to-hand-rotation prediction.
        
        Architecture:
        - Linear embedding layer: projects 62 EEG channels to embedding_dim
        - Positional encoding: adds position information to sequence
        - Transformer encoder: 4 layers with 8 attention heads
        - Global average pooling: aggregates sequence to fixed representation
        - Classification head: outputs class logits and regression value
        """
        def __init__(self, n_channels=62, seq_len=1000, n_classes=5, 
                     embedding_dim=128, n_heads=8, n_layers=4, dropout=0.1):
            super().__init__()
            self.n_channels = n_channels
            self.n_classes = n_classes
            self.embedding_dim = embedding_dim
            
            # Input embedding: project channels to embedding space
            self.embedding = nn.Linear(n_channels, embedding_dim)
            
            # Positional encoding
            self.register_buffer('pos_encoding', self._create_positional_encoding(seq_len, embedding_dim))
            
            # Transformer encoder
            encoder_layer = nn.TransformerEncoderLayer(
                d_model=embedding_dim,
                nhead=n_heads,
                dim_feedforward=embedding_dim * 4,
                dropout=dropout,
                batch_first=True,
                activation='gelu'
            )
            self.transformer_encoder = nn.TransformerEncoder(encoder_layer, num_layers=n_layers)
            
            # Classification and regression heads
            self.class_head = nn.Sequential(
                nn.Linear(embedding_dim, 256),
                nn.ReLU(),
                nn.Dropout(dropout),
                nn.Linear(256, n_classes)
            )
            
            self.regression_head = nn.Sequential(
                nn.Linear(embedding_dim, 256),
                nn.ReLU(),
                nn.Dropout(dropout),
                nn.Linear(256, 1)
            )
        
        def _create_positional_encoding(self, seq_len, d_model):
            """Create sinusoidal positional encoding."""
            position = torch.arange(seq_len).unsqueeze(1).float()
            div_term = torch.exp(torch.arange(0, d_model, 2).float() * 
                                -(np.log(10000.0) / d_model))
            
            pe = torch.zeros(seq_len, d_model)
            pe[:, 0::2] = torch.sin(position * div_term)
            if d_model % 2 == 1:
                pe[:, 1::2] = torch.cos(position * div_term[:-1])
            else:
                pe[:, 1::2] = torch.cos(position * div_term)
            
            return pe.unsqueeze(0)  # (1, seq_len, d_model)
        
        def forward(self, x):
            """
            Forward pass.
            Args:
                x: (batch_size, seq_len, n_channels)
            Returns:
                class_logits: (batch_size, n_classes)
                degrees: (batch_size, 1)
            """
            # Embedding: (batch_size, seq_len, embedding_dim)
            x = self.embedding(x)
            
            # Add positional encoding
            x = x + self.pos_encoding[:, :x.size(1), :]
            
            # Transformer encoding
            x = self.transformer_encoder(x)
            
            # Global average pooling: (batch_size, embedding_dim)
            x = x.mean(dim=1)
            
            # Classification and regression outputs
            class_logits = self.class_head(x)
            degrees = self.regression_head(x)
            
            return class_logits, degrees
else:
    # Placeholder if PyTorch not available
    class EEGTransformer:
        def __init__(self, **kwargs):
            pass

class ModelWrapper:
    def __init__(self):
        self.use_mock = bool(getattr(settings, 'USE_MOCK_MODEL', True))
        self.device = torch.device('cpu') if torch is not None else None
        
        if self.use_mock:
            self.model = DeterministicMock(n_classes=5)
        else:
            # Initialize Transformer model
            if torch is None:
                warnings.warn('PyTorch not available; falling back to mock model')
                self.model = DeterministicMock(n_classes=5)
                self.use_mock = True
            else:
                self.model = EEGTransformer(
                    n_channels=62,
                    seq_len=1000,
                    n_classes=5,
                    embedding_dim=128,
                    n_heads=8,
                    n_layers=4,
                    dropout=0.1
                ).to(self.device)
                self.model.eval()
                
                # Load checkpoint if exists
                ckpt = getattr(settings, 'DEFAULT_CHECKPOINT', None)
                if ckpt and os.path.exists(ckpt):
                    try:
                        state = torch.load(str(ckpt), map_location=self.device)
                        self.model.load_state_dict(state)
                        print(f'Transformer checkpoint loaded from {ckpt}')
                    except Exception as e:
                        warnings.warn(f'Checkpoint load failed: {e}; using random initialization')
                else:
                    warnings.warn(f'No checkpoint found at {ckpt}; using random initialization')
    
    def preprocess(self, raw_array, target_length=1000):
        arr = np.array(raw_array)
        if arr.ndim == 2 and arr.shape[0] > arr.shape[1]:
            arr = arr.T
        if arr.ndim == 1:
            arr = arr[np.newaxis, :]
        channels, samples = arr.shape
        if samples < target_length:
            arr = np.pad(arr, ((0,0),(0,target_length-samples)), mode='constant')
        elif samples > target_length:
            arr = arr[:, :target_length]
        # simple normalization
        arr = (arr - arr.mean(axis=1, keepdims=True)) / (arr.std(axis=1, keepdims=True) + 1e-6)
        return arr
    
    def predict(self, raw_array, target_length=1000):
        arr = self.preprocess(raw_array, target_length=target_length)
        
        if self.use_mock:
            return self.model.predict_from_array(arr)
        else:
            # Transformer prediction
            if torch is None:
                return {'class_idx': 0, 'class_probs': [1.0, 0, 0, 0, 0], 'pred_deg': 0.0}
            
            with torch.no_grad():
                # Convert to tensor: (1, seq_len, n_channels)
                x = torch.from_numpy(arr).unsqueeze(0).float().to(self.device)
                
                # Forward pass
                class_logits, degrees = self.model(x)
                
                # Extract predictions
                class_idx = int(class_logits.argmax(dim=1).item())
                class_probs = torch.softmax(class_logits, dim=1)[0].cpu().numpy().tolist()
                pred_deg = float(torch.clamp(degrees[0, 0], 0, 180).item())
                
                return {
                    'class_idx': class_idx,
                    'class_probs': class_probs,
                    'pred_deg': pred_deg
                }

_MODEL = None
def get_model():
    global _MODEL
    if _MODEL is None:
        _MODEL = ModelWrapper()
    return _MODEL
