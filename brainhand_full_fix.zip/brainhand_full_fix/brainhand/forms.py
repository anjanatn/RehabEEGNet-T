from django import forms
class EEGUploadForm(forms.Form):
    eeg_file = forms.FileField(required=False)
    raw_json = forms.CharField(widget=forms.Textarea, required=False)
