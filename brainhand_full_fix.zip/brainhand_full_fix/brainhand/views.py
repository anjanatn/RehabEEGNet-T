import json, numpy as np
from django.shortcuts import render
from django.http import JsonResponse, HttpResponseBadRequest, FileResponse
from django.views.decorators.csrf import csrf_exempt # pyright: ignore[reportMissingModuleSource]
from .forms import EEGUploadForm
from .model_loader import get_model
from django.conf import settings
import subprocess
import os

ANGLE_LABELS = ['wrist_roll','wrist_pitch','elbow_yaw','elbow_pitch','shoulder_yaw']

def index(request):
    form = EEGUploadForm()
    return render(request, 'brainhand/index.html', {'form': form, 'angle_labels': ANGLE_LABELS})

@csrf_exempt
def predict_ajax(request):
    if request.method != 'POST':
        return HttpResponseBadRequest('Only POST')
    form = EEGUploadForm(request.POST, request.FILES)
    if not form.is_valid():
        return JsonResponse({'error':'Invalid form'}, status=400)
    data_arr = None
    # prefer pasted JSON if present
    raw_json = request.POST.get('raw_json', '').strip()
    if raw_json:
        try:
            parsed = json.loads(raw_json)
            # If wrapped dict, accept {"eeg_data": [...]}
            if isinstance(parsed, dict) and 'eeg_data' in parsed:
                parsed = parsed['eeg_data']
            data_arr = np.array(parsed)
        except Exception as e:
            return JsonResponse({'error': f'Invalid JSON paste: {e}'}, status=400)
    else:
        eeg_file = request.FILES.get('eeg_file')
        if eeg_file:
            content = eeg_file.read()
            # try CSV
            try:
                from io import StringIO, BytesIO
                text = content.decode('utf-8')
                arr = np.loadtxt(StringIO(text), delimiter=',')
                data_arr = arr
            except Exception:
                # try npy
                try:
                    import io
                    data_arr = np.load(io.BytesIO(content), allow_pickle=False)
                except Exception as e:
                    return JsonResponse({'error': f'Could not parse file: {e}'}, status=400)
        else:
            return JsonResponse({'error':'No data provided'}, status=400)
    model = get_model()
    try:
        res = model.predict(data_arr, target_length=1000)
    except Exception as e:
        return JsonResponse({'error': f'Inference failed: {e}'}, status=500)
    label = ANGLE_LABELS[int(res['class_idx'])%len(ANGLE_LABELS)]
    pred_deg = max(0.0, min(360.0, float(res.get('pred_deg', 0.0))))
    return JsonResponse({'label_idx': int(res['class_idx']), 'label': label, 'probs': res.get('class_probs', []), 'pred_deg': pred_deg})



def render_robotic_hand(request):
    blend_file = os.path.join(settings.MEDIA_ROOT, "blender", "robotichand.blend")
    output_path = os.path.join(settings.MEDIA_ROOT, "renders", "robotichand_output.png")
    script_file = os.path.join(settings.BASE_DIR, "scripts", "blender_render.py")

    os.makedirs(os.path.dirname(output_path), exist_ok=True)

    try:
        # Run Blender in headless mode with the render script
        result = subprocess.run(
            [
                settings.BLENDER_PATH,
                "-b", blend_file,
                "--python", script_file,
                "--", output_path, "1"
            ],
            capture_output=True,
            text=True,
            timeout=120
        )
        
        # Check for errors
        if result.returncode != 0:
            error_msg = result.stderr or result.stdout or "Unknown Blender error"
            return JsonResponse(
                {'error': f'Blender render failed: {error_msg}'},
                status=500
            )
        
        # Verify output file was created
        if not os.path.exists(output_path):
            return JsonResponse(
                {'error': 'Render succeeded but output file not found'},
                status=500
            )
        
        # Return the rendered image
        response = FileResponse(
            open(output_path, "rb"),
            content_type="image/png"
        )
        return response
        
    except subprocess.TimeoutExpired:
        return JsonResponse(
            {'error': 'Blender render timed out after 120 seconds'},
            status=500
        )
    except Exception as e:
        return JsonResponse(
            {'error': f'Render failed: {str(e)}'},
            status=500
        )
