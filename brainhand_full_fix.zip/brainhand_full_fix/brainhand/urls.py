from django.urls import path
from . import views
app_name='brainhand'
urlpatterns = [
    path('', views.index, name='index'),
    path('predict_ajax/', views.predict_ajax, name='predict_ajax'),
    path("render-hand/", views.render_robotic_hand, name="render_robotic_hand"),

]
